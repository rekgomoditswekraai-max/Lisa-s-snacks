/* Lisa's Chips Market — shared JavaScript */
document.addEventListener("DOMContentLoaded", () => {
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

  // Footer year and time-based greetings.
  const year = $("#currentYear");
  if (year) year.textContent = new Date().getFullYear();
  const hour = new Date().getHours();
  const greetingText = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const greeting = $("#welcomeGreeting") || $("#greeting");
  if (greeting) greeting.textContent = `${greetingText}! Welcome to Lisa's Chips Market!`;
  const welcome = $("#welcomeMessage");
  if (welcome && welcome.tagName === "P") {
    // Keep the original page message, which may have additional copy.
  }

  // Shared chips interaction, activated by mouse or keyboard.
  const chipsFeature = $("#chipsFeature");
  const chipsEmoji = $("#chipsEmoji") || $(".chips", chipsFeature || document);
  const chipsMessage = $("#chipsMessage");
  const chipsMessages = [
    "Fresh chips, happy customers! 🍟",
    "Life is better with crispy chips! 😋",
    "Thank you for visiting Lisa's Chips Market! ❤️",
    "Fresh • Crispy • Delicious! ⭐",
    "Your favourite snack is waiting for you! 🎉"
  ];
  let chipsIndex = 0;
  function activateChips() {
    if (chipsEmoji) {
      chipsEmoji.classList.remove("spin");
      void chipsEmoji.offsetWidth;
      chipsEmoji.classList.add("spin");
    }
    if (chipsMessage) {
      chipsMessage.textContent = chipsMessages[chipsIndex % chipsMessages.length];
      chipsIndex++;
    }
    const interactionMessage = $("#interactionMessage");
    if (interactionMessage) {
      interactionMessage.hidden = false;
      interactionMessage.textContent = "🍟 Thanks for visiting Lisa's Chips Market! We are proud to offer fresh, crispy chips and friendly service.";
    }
  }
  if (chipsFeature) {
    chipsFeature.addEventListener("click", activateChips);
    chipsFeature.addEventListener("keydown", event => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        activateChips();
      }
    });
  }

  // About page expectation cards.
  const expectationCards = $$(".expect-card");
  expectationCards.forEach(card => {
    const selectCard = () => {
      expectationCards.forEach(item => {
        item.classList.remove("selected");
        item.setAttribute("aria-pressed", "false");
      });
      card.classList.add("selected");
      card.setAttribute("aria-pressed", "true");
      const message = $("#interactionMessage");
      if (message) {
        message.hidden = false;
        message.textContent = card.dataset.message || card.textContent.trim();
      }
    };
    card.addEventListener("click", selectCard);
    card.addEventListener("keydown", event => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectCard();
      }
    });
  });

  // Scroll-to-top control.
  const backToTop = $("#backToTop");
  if (backToTop) {
    const updateBackToTop = () => { backToTop.style.display = window.scrollY > 250 ? "block" : "none"; };
    window.addEventListener("scroll", updateBackToTop, { passive: true });
    updateBackToTop();
    backToTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }

  // Homepage / legacy services page surprise message.
  const surpriseButton = $("#surpriseButton");
  const surpriseMessage = $("#surpriseMessage");
  const surprises = [
    "🍟 Life is better with a packet of chips!",
    "😋 Your next favourite snack could be waiting for you here!",
    "❤️ Good food brings happy moments!",
    "🍔 Chips and a burger make a tasty combination!",
    "🎉 Treat yourself to something delicious today!"
  ];
  if (surpriseButton && surpriseMessage) {
    surpriseButton.addEventListener("click", () => {
      surpriseMessage.textContent = surprises[Math.floor(Math.random() * surprises.length)];
    });
  }

  // Product search and category filtering (supports both supplied product pages).
  const productSearch = $("#productSearch");
  const categoryFilter = $("#categoryFilter");
  const productCards = $$(".product-card[data-name]");
  const searchResults = $("#searchResults");
  const noProducts = $("#noProducts");
  function filterProducts() {
    const term = (productSearch?.value || "").trim().toLowerCase();
    const category = categoryFilter?.value || "all";
    let visible = 0;
    productCards.forEach(card => {
      const name = (card.dataset.name || card.textContent).toLowerCase();
      const matchesTerm = name.includes(term);
      const matchesCategory = category === "all" || !card.dataset.category || card.dataset.category === category;
      const show = matchesTerm && matchesCategory;
      card.hidden = !show;
      card.style.display = show ? "" : "none";
      if (show) visible++;
    });
    if (searchResults) searchResults.textContent = `Showing ${visible} of ${productCards.length} products.`;
    if (noProducts) noProducts.hidden = visible !== 0;
  }
  productSearch?.addEventListener("input", filterProducts);
  categoryFilter?.addEventListener("change", filterProducts);

  // Simple in-page shopping cart. Checkout is a demonstration only; it does not take payment or submit an order.
  const cartItems = $("#cartItems");
  const cartCount = $("#cartCount");
  const cartTotal = $("#cartTotal");
  const cartMessage = $("#cartMessage");
  const checkoutMessage = $("#checkoutMessage");
  const clearCartButton = $("#clearCartButton");
  const checkoutButton = $("#checkoutButton");
  const cart = [];
  const money = value => `R${value.toFixed(2)}`;
  function renderCart() {
    if (!cartItems) return;
    cartItems.replaceChildren();
    if (!cart.length) {
      const empty = document.createElement("p");
      empty.textContent = "Your cart is empty. Add something delicious!";
      cartItems.appendChild(empty);
    }
    let total = 0, count = 0;
    cart.forEach((item, index) => {
      const subtotal = item.price * item.quantity;
      total += subtotal; count += item.quantity;
      const row = document.createElement("div");
      row.className = "cart-item";
      const details = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = item.name;
      const quantity = document.createElement("p");
      quantity.textContent = `Quantity: ${item.quantity}`;
      const price = document.createElement("p");
      price.textContent = `Price each: ${money(item.price)}`;
      const lineTotal = document.createElement("p");
      lineTotal.textContent = `Subtotal: ${money(subtotal)}`;
      details.append(name, quantity, price, lineTotal);
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-cart-button remove-button";
      remove.textContent = "Remove";
      remove.addEventListener("click", () => {
        cart.splice(index, 1);
        if (cartMessage) cartMessage.textContent = `${item.name} removed from your cart.`;
        if (checkoutMessage) checkoutMessage.textContent = "";
        renderCart();
      });
      row.append(details, remove);
      cartItems.appendChild(row);
    });
    if (cartCount) cartCount.textContent = count;
    if (cartTotal) cartTotal.textContent = total.toFixed(2);
  }
  $$(".add-cart-button, .addToCart").forEach(button => {
    button.addEventListener("click", () => {
      const card = button.closest(".product-card");
      const name = button.dataset.name || card?.dataset.name || $("h3", card || document)?.textContent?.trim() || "Product";
      const price = Number(button.dataset.price || card?.dataset.price);
      const quantityInput = $(".quantity-input", card || document);
      const quantity = quantityInput ? Number(quantityInput.value) : 1;
      if (!Number.isFinite(price) || price < 0) {
        if (cartMessage) cartMessage.textContent = "This product does not have a valid price yet.";
        return;
      }
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 99) {
        alert("Please select a quantity between 1 and 99.");
        if (quantityInput) quantityInput.value = 1;
        return;
      }
      const existing = cart.find(item => item.name === name);
      if (existing && existing.quantity + quantity > 99) {
        alert("You can add a maximum of 99 of each product.");
        return;
      }
      if (existing) existing.quantity += quantity;
      else cart.push({ name, price, quantity });
      if (quantityInput) quantityInput.value = 1;
      if (cartMessage) cartMessage.textContent = `${quantity} × ${name} added to your cart!`;
      if (checkoutMessage) checkoutMessage.textContent = "";
      renderCart();
    });
  });
  clearCartButton?.addEventListener("click", () => {
    if (!cart.length) {
      if (cartMessage) cartMessage.textContent = "Your cart is already empty.";
      return;
    }
    if (confirm("Are you sure you want to remove all items from your cart?")) {
      cart.length = 0; renderCart();
      if (cartMessage) cartMessage.textContent = "Your cart has been cleared.";
      if (checkoutMessage) checkoutMessage.textContent = "";
    }
  });
  checkoutButton?.addEventListener("click", () => {
    if (!cart.length) {
      if (cartMessage) cartMessage.textContent = "Your cart is empty. Please add a product before checking out.";
      return;
    }
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    if (confirm(`Confirm this demonstration order?\n\nTotal: ${money(total)}\n\nNo real order or payment will be sent.`)) {
      if (checkoutMessage) checkoutMessage.textContent = "Thank you for choosing Lisa's Chips Market! Your demonstration order has been confirmed. No real order has been sent and no payment has been processed.";
      cart.length = 0; renderCart();
      if (cartMessage) cartMessage.textContent = "";
      checkoutMessage?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  });
  if (cartItems) renderCart();

  // Contact form: validation plus a mailto hand-off (no server/backend is connected).
  const contactForm = $("#contactForm");
  const contactMessage = $("#customerMessage");
  const messageCounter = $("#messageCounter");
  const feedback = $("#formFeedback");
  function updateMessageCounter() {
    if (messageCounter && contactMessage) messageCounter.textContent = `${contactMessage.value.length} / ${contactMessage.maxLength || 500} characters`;
  }
  contactMessage?.addEventListener("input", updateMessageCounter);
  updateMessageCounter();
  $("#clearFormButton")?.addEventListener("click", () => {
    contactForm?.reset(); updateMessageCounter();
    if (feedback) { feedback.className = ""; feedback.textContent = ""; }
  });
  contactForm?.addEventListener("submit", event => {
    event.preventDefault();
    if (!contactForm.reportValidity()) return;
    const name = $("#customerName")?.value.trim() || "";
    const email = $("#customerEmail")?.value.trim() || "";
    const subject = $("#messageSubject")?.value.trim() || "Website enquiry";
    const body = `Name: ${name}\nEmail: ${email}\n\n${contactMessage?.value || ""}`;
    if (feedback) {
      feedback.className = "success";
      feedback.textContent = "Your email application will open with this message prepared. The website itself does not send or store messages.";
    }
    window.location.href = `mailto:info@lisaschipsmarket.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  });

  // Customer review star selector and local page-only review display.
  let selectedRating = 0;
  const starButtons = $$("#starRating button");
  const ratingMessage = $("#ratingMessage");
  function setRating(value) {
    selectedRating = value;
    starButtons.forEach(button => {
      const active = Number(button.dataset.rating) <= value;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(Number(button.dataset.rating) === value));
    });
    if (ratingMessage) ratingMessage.textContent = `${value} out of 5 stars selected.`;
  }
  starButtons.forEach(button => button.addEventListener("click", () => setRating(Number(button.dataset.rating))));
  const reviewText = $("#customerReview");
  const characterCounter = $("#characterCounter");
  const clearReviewButton = $("#clearReviewButton");
  const reviewForm = $("#reviewForm");
  const reviewFeedback = $("#formFeedback");
  function updateReviewCounter() {
    if (characterCounter && reviewText) characterCounter.textContent = `${reviewText.value.length} / ${reviewText.maxLength || 500} characters`;
  }
  reviewText?.addEventListener("input", updateReviewCounter);
  updateReviewCounter();
  clearReviewButton?.addEventListener("click", () => {
    reviewForm?.reset(); setRating(0); updateReviewCounter();
    if (reviewFeedback) { reviewFeedback.className = ""; reviewFeedback.textContent = ""; }
  });
  reviewForm?.addEventListener("submit", event => {
    event.preventDefault();
    if (!reviewForm.reportValidity()) return;
    if (!selectedRating) {
      if (ratingMessage) ratingMessage.textContent = "Please select a star rating before submitting.";
      return;
    }
    const name = $("#customerName")?.value.trim() || "Customer";
    const text = reviewText?.value.trim() || "";
    const container = $("#reviewContainer");
    if (container) {
      const card = document.createElement("article");
      card.className = "review-card new-review";
      const stars = document.createElement("div"); stars.className = "stars"; stars.textContent = "★".repeat(selectedRating);
      const heading = document.createElement("h3"); heading.textContent = name;
      const paragraph = document.createElement("p"); paragraph.textContent = `“${text}”`;
      card.append(stars, heading, paragraph); container.prepend(card);
    }
    if (reviewFeedback) {
      reviewFeedback.className = "success";
      reviewFeedback.textContent = "Thank you! Your review has been added to this page for this session only. It is not stored or published online.";
    }
    const total = $("#totalReviews");
    if (total) total.textContent = `Total Reviews: ${$$(".review-card", $("#reviewContainer") || document).length}`;
    reviewForm.reset(); setRating(0); updateReviewCounter();
  });

  // Review search.
  const reviewSearch = $("#reviewSearch");
  reviewSearch?.addEventListener("input", () => {
    const term = reviewSearch.value.trim().toLowerCase();
    const cards = $$(".review-card", $("#reviewContainer") || document);
    let shown = 0;
    cards.forEach(card => {
      const match = card.textContent.toLowerCase().includes(term);
      card.hidden = !match;
      if (match) shown++;
    });
    const message = $("#searchMessage");
    if (message) message.textContent = `Showing ${shown} of ${cards.length} customer reviews.`;
  });

  // Accessible logo interaction and a small console confirmation.
  $$(".middle-logo").forEach(logo => {
    logo.addEventListener("click", () => {
      logo.classList.add("logo-pop");
      logo.style.transform = "scale(1.06)";
      window.setTimeout(() => { logo.style.transform = ""; logo.classList.remove("logo-pop"); }, 350);
    });
  });
  console.log("Lisa's Chips Market website is ready.");
});
